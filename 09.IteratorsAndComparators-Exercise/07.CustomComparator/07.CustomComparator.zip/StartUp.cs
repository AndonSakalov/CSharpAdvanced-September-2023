﻿using System.Collections;

namespace _07.CustomComparator
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int[] arr = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray();
            Array.Sort(arr, new Comparer());
            Console.WriteLine(string.Join(" ", arr));
        }
    }
}